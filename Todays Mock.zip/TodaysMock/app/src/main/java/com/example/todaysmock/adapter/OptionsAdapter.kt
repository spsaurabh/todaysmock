package com.example.todaysmock.adapter

import android.content.Context
import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.DrawableCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.todaysmock.R
import com.example.todaysmock.databinding.AdapteroptionsBinding

class OptionsAdapter(val context: Context,val answerList:ArrayList<String>,
                     var onItemClicked: ((clickedItem: Int,String) -> Unit)):
    RecyclerView.Adapter<OptionsAdapter.QuestionsViewHolder>() {
    private var selectedPosition = RecyclerView.NO_POSITION

    inner class QuestionsViewHolder(var binding:AdapteroptionsBinding):RecyclerView.ViewHolder(binding.root){
        fun bind(item: String,isSelected: Boolean) {
            binding.cvAnswer.isSelected=isSelected
            val backgroundColorStateList = ContextCompat.getColorStateList (context,R.color.selectedadapter)
            DrawableCompat.setTintList(binding.cvAnswer.background,backgroundColorStateList)
//            (if (isSelected) ContextCompat.getColor(context, R.color.selectedadapter) else Color.WHITE)
        }
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): QuestionsViewHolder {
        val binding =AdapteroptionsBinding.inflate(LayoutInflater.from(parent.context),parent,false)
        return QuestionsViewHolder(binding)
    }
    override fun getItemCount(): Int {
        return answerList.size
    }
    override fun onBindViewHolder(holder: QuestionsViewHolder, position: Int) {
        with(holder.binding){
            tvoption.text=answerList[position]
            cvAnswer.setOnClickListener {
                onItemClicked(position,answerList[position])
                holder.bind(answerList[position], position == selectedPosition)
            }
        }
    }
}