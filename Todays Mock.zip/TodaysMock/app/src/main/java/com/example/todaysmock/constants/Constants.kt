package com.example.todaysmock.constants

class Constants {
    companion object{
        var API_AMOUNT="api.php?amount"
    }
}